public class RelationalOperator {
	
	public static void main(String[] args) {
		int x=5;
		int y=8;
		int z=10;

		boolean res;
		
        res= x==y;
		System.out.println(res);
 
        res= x!=y;
		System.out.println(res);
                          
         res= x>y;
		System.out.println(res);
         res= x<y;
		System.out.println(res);

        res= x>=y;
		System.out.println(res);

        res= x<=y;
		System.out.println(res);
                              
		res= x>=y && y >=z;                                 
		System.out.println(res);

	}

}
