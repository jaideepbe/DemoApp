class WithOutMain{  
 static{  
  System.out.println("Message: Your message can be print on console without main() method");  
  System.exit(0);  
 }  
}