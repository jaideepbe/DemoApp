class DemoClass
{
     static
     {
         System.out.println("SIB of class A");
     }
    DemoClass()
    {
       System.out.println ("Constructor of class A");
    }
   {
      System.out.println("IIB of class A");
   }
}
class  FlowOverview
{
      public static void main(String[] args) 
     {
         System.out.println("main starts");
		 DemoClass a1=new DemoClass();
         System.out.println("main  ends");
  }
}
