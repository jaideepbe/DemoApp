class AssignmentOperators{

	public static void main(String[] args) {
                        
	int i=2,j=3,k=4,l=25,m=7;
	
    i+=5;
    j*=6;
    k/=2;
    l-=10;
    m%=5;                       
    System.out.println(i);
    System.out.println(j);
    System.out.println(k);
    System.out.println(l);
    System.out.println(m);		                         		
	}
}
