class SimpleClass
{
    int i;
    int j;
   SimpleClass()
    {
       i=10;
       j=20;
    }
}
public class  ConstructorExample
{
     public static void main(String[] args) 
     {
        System.out.println("main starts");        
		SimpleClass simpleClassObj=new SimpleClass();
        System.out.println("i="+simpleClassObj.i);
        System.out.println("j="+simpleClassObj.j);
        System.out.println("main ends");
   }
}
