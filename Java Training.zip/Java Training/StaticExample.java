class  StaticExample
{
    static int i=20;
	public static void main(String[] args) 
	{
		System.out.println("main starts");
		StaticExample.test();
		//StaticExample.test2();
		StaticExample staticExampleObj = new StaticExample();
		staticExampleObj.test2();
		
		System.out.println("main ends.....");
	}
	static void test()
	{
	   System.out.println("i="+ StaticExample.i);
	}
	void test2(){
		System.out.println("i="+ StaticExample.i);
	}

}
