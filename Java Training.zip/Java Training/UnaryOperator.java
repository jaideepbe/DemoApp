class  UnaryOperator
{
	public static void main(String[] args) 
	{
		System.out.println("main starts");
		int i=0;
		int j;
		j=i++; // Use first the current value and then increment
		System.out.println("i="+i);
        System.out.println("j="+j);
        System.out.println("main ends.....");
	}
}
