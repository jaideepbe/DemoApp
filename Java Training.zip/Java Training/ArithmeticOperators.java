class ArithmeticOperators{
	public static void main(String[] args) {
		int i,j,k;
		i=30;
		j=20;
		
		k=i+j;
		System.out.println("Sum of i and j is " + k);
		
		k=i-j;
		System.out.println("Difference of i and j is " + k);
		
		k=i*j;
		System.out.println("Product of i and j is " + k);
		
		k=i/j;
		System.out.println("Division of i and j is " + k);
		
		k=i%j;
		System.out.println("Reminder of i and j is " + k);
	}

}
