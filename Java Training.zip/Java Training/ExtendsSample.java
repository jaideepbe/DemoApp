class A
{
int i;
int j;
void print(){
          System.out.println("i="+i);
          System.out.println("j="+j);
}
}

class B extends A
{
int a;
int b;

void disp(){
        System.out.println("a="+a);
        System.out.println("b="+b);
}
}    

class ExtendsSample
{
  public static void main(String[] args) 
   {
System.out.println("main method starts....");
System.out.println("using reference variable of classA");
		A a1=new A();
           a1.print();
           a1.i=100;
           a1.j=200;
           a1.print();
System.out.println("..............");
System.out.println("using reference variable of classB");
        B b1=new B();
           b1.disp();
           b1.print();
           b1.i=1000;
           b1.j=2000;
           b1.a=1500;
           b1.b=2500;
           b1.print();
           b1.disp();
System.out.println("main method ends...");
  }
}
