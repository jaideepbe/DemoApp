
class C
{
   int i;
   int j;
   C(int i,int j)
   {
    this.i=i;
    this.j=j;
   }
   void print(){
    System.out.println("i="+i);
    System.out.println("j="+j);
   }
}


class D extends C
{
   int x;
   int y;

   D(int x,int y)
   {
      super(x,y);
      this.x=x+1;
      this.y=y+1;
   }
	
   void disp(){
     System.out.println("x="+x);
     System.out.println("y="+y);
   }
}    

public class ThisSuperExample
{
    public static void main(String[] args) 
    {
       System.out.println("main method starts....");
       D d1=new D(10,20);
       d1.print();
       d1.disp();
       System.out.println("main method ends...");
    }
}
