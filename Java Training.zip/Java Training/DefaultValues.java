public class DefaultValues
{
	static byte b;
	static short s;
	static int i;
	static long l;
	static float f;
	static double d;
	static char c;
	static boolean flag;
	static String str;

	public static void main(String[] args) 
	{
		System.out.println("main program starts");
        System.out.println("default value of byte is"+b);
        System.out.println("default value of short is"+s);
		System.out.println("default value of int is"+i);
		System.out.println("default value of long is"+l);
		System.out.println("default value of float is"+f);
		System.out.println("default value of double is"+d);
		System.out.println("default value of char is"+c);
		System.out.println("default value of boolean is"+flag);
		System.out.println("default value of string is "+ str);
	}
}
