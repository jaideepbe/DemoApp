class StaticBlockExample2{

    int i,j;

    public static void main(String args[])
    {
       System.out.println("main starts");
       StaticBlockExample2 d1=new StaticBlockExample2();
       System.out.println("i="+ d1.i);
       System.out.println("j="+ d1.j);
       System.out.println("............");
       
       StaticBlockExample2 d2=new StaticBlockExample2(); 
       System.out.println("i="+ d2.i);
       System.out.println("j="+ d2.j);
       System.out.println("............");       

       d1.i=123;
	   d1.j=456;
               
       System.out.println("i="+ d1.i);
       System.out.println("j="+ d1.j);
	   System.out.println("............");      
       System.out.println("i="+ d2.i);
       System.out.println("j="+ d2.j);
       System.out.println("............");
	   
       System.out.println("main ends");
    }

    {
		//instance initialization block(IIB)
         System.out.println("1: Non static block");
          i=20;        
          j=30;
    }

   {
         System.out.println("2: Non static block");
         i=200;
         j=300;
   }
}
