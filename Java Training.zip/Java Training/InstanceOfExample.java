class InstanceOfExample{


      public static void main(String args[])
     {

        String s=new String("Hello");

       if(s instanceof  String)
      {
         System.out.println("s is an instance of String");

      }  

    }

}
