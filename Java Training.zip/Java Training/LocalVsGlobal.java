class LocalVsGlobal{
	
	static int dummy1;
	//dummy1=10;
	public static void main(String args[]){
	System.out.println("dummy1 value is " + dummy1);
	//int dummy1;
	//System.out.println("dummy1 value is " + dummy1);
	dummy1 = 100;	
	System.out.println("dummy1 value is " + dummy1);
	}
}