class  StaticBlockExample
{
     static 
     {
        System.out.println("Static 1: I am the first to execute");
     }
      static 
     {
        System.out.println("Static 2: I am the first to execute");
     }  
     public static void main(String[] args) 
    {
       System.out.println("main  starts");
       System.out.println("main ends.....");
    }
	
 static 
   {
	   //Static Initialization Block(SIB)
      System.out.println("Static 3: I am the first to execute");

   } 
}
