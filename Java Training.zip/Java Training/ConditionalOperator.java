public class ConditionalOperator {

	
	public static void main(String[] args) {
		int i=20,j=25;

		boolean test=false;

		test=i>j ? true :false;
        System.out.println("The value of test " + test);

	}

}
