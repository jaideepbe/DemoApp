var fullViewDiv = '<div class="fvElem">';
var headingDiv = '<div class="displayHeading">';
var contentDiv = '<div class="displayContent">';

var splitViewDiv = '<div class="svElem">';

var closingDiv = '</div>';


$( document ).ready(function() {
	$( "#accntActivityLink" ).click(function(e) {
		  e.preventDefault();
		  var href="http://localhost:8080/AccountActivity/AccountActivityAction";
		  
		  $.ajax({
			  url: href,
			  cache: false,
			  success: function(data){
			    loadActivityPage(data);
			  }
		});
	});
	
});
function returnJSON(json) {
    try {
       var data = JSON.parse(json);
    } catch (e) {
        return json;
    }
    return data;
}
function loadActivityPage(json){
	var acActivityJson = returnJSON(json);
	
	$.mobile.changePage("#accntActivityPage",{
		allowSamePageTransition: true,
		transition: 'none',
		reloadPage: false
	});
	
	console.log(acActivityJson);
	
	if(acActivityJson.error ==null){
		var valnDte = 'May 04,2017';
		var disclaimerDesc = 'Financial Summary is up to date as of '+valnDte+'.';
		$("#finSummDsclr").text(disclaimerDesc);
		
		var acFinSummObj = acActivityJson.finSummInfo;
		loadFinancialSummary(acFinSummObj);
		
		var acDtlObj = acActivityJson.accountInfo;
		loadAccountDetailSection(acDtlObj);
	}else{
		$('#accActivityContent').css("display","none");
		$('#accntActivityError').css("display","block");
	}
}

function loadFinancialSummary(json){
	var elem;
	
	//Changes for Man Agg and Partnership Accounts
	if(json.acTypeGrpDcde == 'MAG' || json.acTypeGrpDcde == 'PTR'){
		elem = splitWidthElem("Total Cost","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Market Value","Data need to be identified");
		$("#finSummContent").append(elem);

		elem = splitWidthElem("Unrealized Gain/Loss","Data need to be identified");
		$("#finSummContent").append(elem);
		
		if (json.dtlAcType == 'AIN'){
			elem = splitWidthElem("Commitment Amount","Data need to be identified");
			$("#finSummContent").append(elem);
			
			elem = fullWidthElem("Funded Amount","Data need to be identified");
			$("#finSummContent").append(elem);
		}
		
		if(json.dtlAcType == 'POR'){
			$("#assetClpSet").css("display","block");
			
			/*
			 * 
			 *  Need Logic to iterate arraylist for number of accounts 
			 * 
			 * 
			 */
			
			elem = fullWidthElem("Asset Description - Asset ID","Data need to be identified");
			$("#assetSummContent").append(elem);
			
			elem = fullWidthElem("Shares","Data need to be identified");
			$("#assetSummContent").append(elem);

			elem = splitWidthElem("Total Cost","Data need to be identified");
			$("#assetSummContent").append(elem);
			
			elem = splitWidthElem("Market Value","Data need to be identified");
			$("#assetSummContent").append(elem);

			/******
			 * 
			 * 
			 * need an logic to check if account is commited and funded or not
			 */
			elem = splitWidthElem("Funded Amount","Data need to be identified");
			$("#assetSummContent").append(elem);

			elem = splitWidthElem("Commitment Amount","Data need to be identified");
			$("#assetSummContent").append(elem);
		}
		
	}

	//Changes for IMAS/NIC, Securities Custody, Revocable Trust, Irrevocable Trust
	if(json.dtlAcType == 'IMA' || json.dtlAcType == 'SEC' || json.dtlAcType == 'RTR' || json.dtlAcType == 'ITR'){
		
		elem = splitWidthElem("Total Cash Balance","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Market Value","Data need to be identified");
		$("#finSummContent").append(elem);

		elem = splitWidthElem("Unrealized Gain/Loss","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Accrued Income/Expense","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Total Cost","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Market Value Incl. Accruals","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Principal Cash Balance","Data need to be identified");
		$("#finSummContent").append(elem);

		elem = splitWidthElem("Income Cash Balance","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = fullWidthElem("Reserve Cash Balance","Data need to be identified");
		$("#finSummContent").append(elem);
	}
	
	//Change for Savings / Money Market Demand Account
	if(json.dtlAcType == 'SAV' || json.dtlAcType == 'MMD'){
		
		elem = splitWidthElem("Current Balance","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Current Available Balance","Data need to be identified");
		$("#finSummContent").append(elem);

		elem = splitWidthElem("Current Ledger Balance","Data need to be identified");
		$("#finSummContent").append(elem);

		elem = splitWidthElem("Closing Period's APY","Need to identify data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Current Rate","Need to identify data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Current APY","Need to identify data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Interest Paid YTD","Need to identify data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Taxes withheld YTD","Need to identify data");
		$("#finSummContent").append(elem);
	}
	
	//Change for Anchor Checking
	if(json.dtlAcType == 'ACK'){
		elem = splitWidthElem("Current Balance","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Current Available Balance","Data need to be identified");
		$("#finSummContent").append(elem);

		elem = splitWidthElem("Current Ledger Balance","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Account Type","Data need to be identified");
		$("#finSummContent").append(elem);
		
		/* 
		 * Check if the account is northern line and enable below data
		 * 
		 */
		elem = splitWidthElem("Maximum Northern Line","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Northern Line in Use","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = fullWidthElem("Available Credit","Data need to be identified");
		$("#finSummContent").append(elem);
	}
	
	//Changes for Checking accounts
	if(json.dtlAcType == 'CHK'){
		elem = splitWidthElem("Current Balance","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Current Available Balance","Data need to be identified");
		$("#finSummContent").append(elem);

		elem = splitWidthElem("Current Ledger Balance","Data need to be identified");
		$("#finSummContent").append(elem);
		/* 
		 * Check if the account is northern line and enable below data
		 * 
		 */
		elem = splitWidthElem("Maximum Northern Line","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Northern Line in Use","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Available Credit","Data need to be identified");
		$("#finSummContent").append(elem);
	}
	
	//Changes for Interest Checking
	if(json.dtlAcType == 'ICK'){
		elem = splitWidthElem("Current Balance","Need to identify data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Current Available Balance","Need to identify data");
		$("#finSummContent").append(elem);

		elem = splitWidthElem("Current Ledger Balance","Need to identify data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Last Period's APY","Need to identify data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Current Rate","Need to identify data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Current APY","Need to identify data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Interest Paid YTD","Need to identify data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Taxes withheld YTD","Need to identify data");
		$("#finSummContent").append(elem);
		
		/* 
		 * Check if the account is northern line and enable below data
		 * 
		 */
		elem = splitWidthElem("Maximum Northern Line","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Northern Line in Use","Data need to be identified");
		$("#finSummContent").append(elem);
		
		elem = fullWidthElem("Available Credit","Data need to be identified");
		$("#finSummContent").append(elem);
	}
	
	//Changes for Mortgage loan
	if(json.dtlAcType == 'MOL'){
		elem = splitWidthElem("Current Balance",json.mvBseAmt);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Original Loan Amount",json.origInstlLoanAmt);
		$("#finSummContent").append(elem);

		elem = splitWidthElem("Payment Amount",json.pmtDueAmount);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Payment Due Date",json.pmtDueDate);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Payoff Amount",json.payoffAmt);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("APR",json.aprRtAmt);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Escrow",json.escrowAmt);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Principal Interest",json.prinIntAmt);
		$("#finSummContent").append(elem);
		
		elem = fullWidthElem("Private Mortgage Insurance",json.pmiAmt);
		$("#finSummContent").append(elem);
			
	}
	
	
	//Changes for Installment Loan
	if(json.dtlAcType == 'INL'){
		elem = splitWidthElem("Current Balance",json.mvBseAmt);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Original Loan Amount",json.origInstlLoanAmt);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Payment Amount",json.pmtDueAmount);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Payment Due Date",json.pmtDueDate);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Payoff Amount",json.payoffAmt);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("APR",json.aprRtAmt);
		$("#finSummContent").append(elem);
	}
	
	//Changes for Certificate Of Deposit type accounts
	if(json.dtlAcType == 'CD'){
		elem = splitWidthElem("CD Account","What need to be displayed here");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Maturity Date","Analyse Db data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Current Balance",json.acMvBseAmt);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Current Rate",json.curRtAmt);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Term",json.termCdQtyNbr);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Last Interest Payment","Need to identify data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Interest Paid YTD","Need to identify data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Taxes withheld YTD","Need to identify data");
		$("#finSummContent").append(elem);
	}
	
	//Changes for 56 account types - Mutual Funds
	 if(json.acTypeGrpDcde == 'MUT'){
		 elem = splitWidthElem("Shares Owned",json.shrHld);
		$("#finSummContent").append(elem);
			
		elem = splitWidthElem("Market Value",json.acMvBseAmt);
		$("#finSummContent").append(elem);
		
		elem = fullWidthElem("Share Price",json.mktPrcLclAmt);
		$("#finSummContent").append(elem);
	 }
	
	 //Changes for Brokerage account types
	if(json.dtlAcType == 'BRK'){
		elem = splitWidthElem("Cash or Margin","Need to get data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Market Value",json.acMvBseAmt);
		$("#finSummContent").append(elem);
	}
	
	//Changes for 34 account Types External Advanced Aggregator
	if(json.acTypeGrpDcde == 'PIA'){		
		
		elem = splitWidthElem("Total Cash Balance","Need to get data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Market Value","Need to get data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Unrealized Gain/Loss", "Need to get data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Accrued Income/Expense","Need to get data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Total Cost","Need to get data");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Market Value Incl. Accruals","Need to get data");
		$("#finSummContent").append(elem);
		
	}
	
	
	//Changes for External Advanced Aggregator - Checkings & Savings
	if(json.acTypeGrpDcde == 'PCA'){
		elem = fullWidthElem("Current Balance",json.acMvBseAmt);
		$("#finSummContent").append(elem);
	}
	
	//Changes for Yodlee (External REtail Aggregator) - Banking, Investment, Insurance
	if(json.acTypeGrpDcde == 'YIN'){
		elem = splitWidthElem("Current Balance",json.acMvBseAmt);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Last Valuation Date",json.lastValuationDate);
		$("#finSummContent").append(elem);
	}
	
	
	//Changes for Yodlee(External Retail aggregator) - Credit Card, Home Equity Line, General Loan, Mortgage Loan
	if(json.acTypeGrpDcde == 'YLN'){
		elem = splitWidthElem("Current Balance",json.acMvBseAmt);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Last Valuation Date",json.lastValuationDate);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Last Payment Amount",json.pmtDueAmount);
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Last Payment Due Date",json.pmtDueDate);
		$("#finSummContent").append(elem);
		
		if(json.dtlAcType != 'CRD'){
			
			elem = splitWidthElem("Original Loan Amount",json.origInstlLoanAmt);
			$("#finSummContent").append(elem);
			
			elem = splitWidthElem("Original Loan Date",json.origLoanDueDate);
			$("#finSummContent").append(elem);
		}else{
			elem = splitWidthElem("Available Credit Amount",json.availCrAmt);
			$("#finSummContent").append(elem);
		}
		elem =  splitWidthElem("Rate","Value need to be identified");
		$("#finSummContent").append(elem);
	}
	
	
	//If no wealth client has how to get data from db - have to analyse
	if(json.acTypeGrpDcde == 'YRW'){
		elem = splitWidthElem("Current Balance","Verify data in DB and account Info");
		$("#finSummContent").append(elem);
		
		elem = splitWidthElem("Last Valuation Date","Verify data in DB and account Info");
		$("#finSummContent").append(elem);
		
		elem = fullWidthElem("Description","Verify data in DB and account Info");
		$("#finSummContent").append(elem);
	}
	
}

function loadAccountDetailSection(json){
	var elem = fullWidthElem("Account Name",json.accountDesc);
	$("#acDtlCollapsibleCnt").append(elem);
	
	if(json.accountAlias != null){
		elem = fullWidthElem("Alias",json.accountAlias);
		$("#acDtlCollapsibleCnt").append(elem);
	}
	if(json.dataSrcID == 12 && json.partnerID!=null){
		elem = fullWidthElem("Partner ID",json.partnerID);
		$("#acDtlCollapsibleCnt").append(elem);
	}
	
	if(json.accountId !=null){
		elem = splitWidthElem("Account ID",json.accountId);
		$("#acDtlCollapsibleCnt").append(elem);
	}
	
	if(json.taxId != null){
		elem = splitWidthElem("Tax ID",json.taxId);
		$("#acDtlCollapsibleCnt").append(elem);
	}
	
	if(json.accountTypeDesc != null){
		elem = splitWidthElem("Account Type",json.accountTypeDesc);
		$("#acDtlCollapsibleCnt").append(elem);
	}
	
	if(json.liabFlagDcde != null){
		elem = splitWidthElem("Category",json.liabFlagDcde);
		$("#acDtlCollapsibleCnt").append(elem);
	}

	if(json.invObjDcde != null){
		elem = splitWidthElem("Investment Objective",json.invObjDcde);
		$("#acDtlCollapsibleCnt").append(elem);
	}
	
	if(json.fiscalYearEnd != null){
		elem = splitWidthElem("Fiscal Year End",json.fiscalYearEnd);
		$("#acDtlCollapsibleCnt").append(elem);
	}
	
	if(true){
		elem = splitWidthElem("Source","Value need to be identified");
		$("#acDtlCollapsibleCnt").append(elem);
	}
	
	if(json.baseCurrency != null){
		elem = splitWidthElem("Base Currrency",json.baseCurrency);
		$("#acDtlCollapsibleCnt").append(elem);
	}
	
	if(json.attributeDesc1 != null){
		elem = splitWidthElem("Attribute 1",json.attributeDesc1);
		$("#acDtlCollapsibleCnt").append(elem);
	}

	if(json.attributeDesc2 != null){
		elem = splitWidthElem("Attribute 2",json.attributeDesc2);
		$("#acDtlCollapsibleCnt").append(elem);
	}
	
	if(json.attributeDesc3 != null){
		elem = splitWidthElem("Attribute 3",json.attributeDesc3);
		$("#acDtlCollapsibleCnt").append(elem);
	}
	
	if(json.attributeDesc4 !=null){
		elem = splitWidthElem("Attribute 4",json.attributeDesc4);
		$("#acDtlCollapsibleCnt").append(elem);
	}
	
	if(json.attributeDesc5 !=null){
		elem = splitWidthElem("Attribute 5",json.attributeDesc5);
		$("#acDtlCollapsibleCnt").append(elem);
	}
	
	if(true){
		//if(json.dataSrcID == 3 )
		elem = splitWidthElem("Fund Profile","Value need to be identified");
		$("#acDtlCollapsibleCnt").append(elem);
	}
	
	if(json.acTypeGrpDcde == 'MAG'){
		
		if(json.dtlAccountType != 'POR'){
			if(json.assetAcquiredDate != null){
				elem = splitWidthElem("Acquired Date",json.assetAcquiredDate);
				$("#acDtlCollapsibleCnt").append(elem);
			}
			if(json.localCurrency != null){
				elem = splitWidthElem("Local Currency of Asset",json.localCurrency);
				$("#acDtlCollapsibleCnt").append(elem);
			}
		}
		if(json.dtlAccountType == 'AIN'){
			if(json.vintageYr != null){
				elem = splitWidthElem("Vintage Year",json.vintageYr);
				$("#acDtlCollapsibleCnt").append(elem);
			}
			if(json.fundTypeDesc != null){
				elem = splitWidthElem("Fund Type",json.fundTypeDesc);
				$("#acDtlCollapsibleCnt").append(elem);
			}		
		}
			
		if(json.benchMarkDesc != null){
			elem = splitWidthElem("Benchmark",json.benchMarkDesc);
			$("#acDtlCollapsibleCnt").append(elem);
		}
		
		if(json.dtlAccountTypeDesc != null){
			elem = splitWidthElem("Aggregation Account Type",json.dtlAccountTypeDesc);
			$("#acDtlCollapsibleCnt").append(elem);
		}

		if(json.dtlAccountType != 'POR'){
			if(json.manAggrAssetId != null){
				elem = splitWidthElem("Aggregation Asset ID",json.manAggrAssetId);
				$("#acDtlCollapsibleCnt").append(elem);
			}
			if(json.issueType != null){
				elem = splitWidthElem("Asset Subcategory",json.issueType);
				$("#acDtlCollapsibleCnt").append(elem);
			}
		}	
	}
	if(json.acTypeGrpDcde == 'MAG' || json.acTypeGrpDcde == 'PTR'){
		if(json.accountCreatedTime != null){
			elem = splitWidthElem("Date Created",json.accountCreatedTime);
			$("#acDtlCollapsibleCnt").append(elem);
		}
		if(json.accountCreatedBy != null){
			elem = splitWidthElem("Created By",json.accountCreatedBy);
			$("#acDtlCollapsibleCnt").append(elem);
		}		
	}
	if(json.serviceProviderDesc != null){
		elem = splitWidthElem("Related Website",json.serviceProviderDesc);
		$("#acDtlCollapsibleCnt").append(elem);
	}
	if(json.serviceProviderURLDesc != null){
		elem = splitWidthElem("Related Website URL",json.serviceProviderURLDesc);
		$("#acDtlCollapsibleCnt").append(elem);
	}	

	if(json.memoField != null){
		elem = fullWidthElem("Memo",json.memoField);
		$("#acDtlCollapsibleCnt").append(elem);
	}
}




//Util Functions
function fullWidthElem(header,value){
	var elem = fullViewDiv 
		+ headingDiv	+ header + closingDiv
		+ contentDiv + value + closingDiv
		+ closingDiv;
	
	return elem;
}

function splitWidthElem(header,value){
	var elem = splitViewDiv
			+ headingDiv	+ header + closingDiv
			+ contentDiv + value + closingDiv
			+ closingDiv;
	
	return elem;
}